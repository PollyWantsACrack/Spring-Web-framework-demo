package org.example.springweb.repositories;

import org.example.springweb.models.Product;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class dbRepository {
    private JdbcTemplate jdbcTemplate;

    public dbRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Product> getAllProducts(){
        String sql = "select * from products";
        return jdbcTemplate.query(
                sql,
                BeanPropertyRowMapper.newInstance(Product.class)
        );
    }

    public void AddProduct(Product product) {
    String sql = "INSERT INTO products (category_id, name, description, price, img) VALUES (?, ?, ?, ?, ?)";
    jdbcTemplate.update(sql, product.getCategory_id(), product.getName(), product.getDescription(), product.getPrice(), product.getImg());
    }



//    public void UpdateCategory(int numerWiersza,String tekst) {
//        //String sql2 = "UPDATE `products` SET `" + nazwaKolumny + "` = '" + tekst + "' WHERE `id` = " + numerWiersza;
//        String sql = "UPDATE products SET name = ? WHERE id = ?";
//        jdbcTemplate.update(sql, tekst, numerWiersza);
//    }
    /*public String UpdateCategory2(String nazwaKolumny, int numerWiersza, String tekst) {
        String sql = "UPDATE `products` SET `" + nazwaKolumny + "` = '" + tekst + "' WHERE `id` = " + numerWiersza;
        return sql;
    }*/

//    public List<Map<String, Object>> getAllProducts2(){
//        String sql = "select * from products";
//        return jdbcTemplate.queryForList(sql);
//    }


}
