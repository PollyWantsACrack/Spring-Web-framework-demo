package org.example.springweb.controllers;

import org.example.springweb.models.Product;
import org.example.springweb.repositories.dbRepository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
    private dbRepository dbRepo;

    public TestController(dbRepository dbRepo) {
        this.dbRepo = dbRepo;
    }
    @PostMapping("/addertest")
    public Product test(Product product)
    {
        return product;
    }

}
