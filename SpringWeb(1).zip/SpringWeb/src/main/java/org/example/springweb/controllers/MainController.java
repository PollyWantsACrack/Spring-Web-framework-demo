package org.example.springweb.controllers;
import org.example.springweb.models.Product;
import org.example.springweb.repositories.dbRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MainController {

    private dbRepository dbRepo;

    public MainController(dbRepository dbRepo) {
        this.dbRepo = dbRepo;
    }

    @GetMapping("/shop")
    public String products(Model m) {

        var products = dbRepo.getAllProducts();
        m.addAttribute("products", products);
        return "mainShopPage";


    }

    @GetMapping("/newProduct")
    public String createForm() {
        return "createForm";

    }
    @PostMapping("/adder")
    public String createProduct(Product product)
    {
        dbRepo.AddProduct(product);
        return "redirect:/shop";
    }

























//    @GetMapping("/insert")
//    public String testUpdateCategory() {
//        String nazwaKolumny = "category_id";
//        int productId = 3;
//        String newName = "pizza";
//
//
//        dbRepo.UpdateCategory(productId, newName);
//        return "oldInsert";
//
//    }
//    public void testUpdateCategory() {
//        int productId = 1;
//        String newName = "Nowa nazwa produktu";
//
//
//        dbRepo.UpdateCategory(productId, newName);
//
//
//    }



}
