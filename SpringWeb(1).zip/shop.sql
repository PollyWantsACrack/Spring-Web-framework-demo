-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Lis 08, 2024 at 11:12 AM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sklep3tc2`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `img`) VALUES
(1, 1, 'Lodówka Samsung RT38K', 'Lodówka o pojemności 380 litrów, z systemem No Frost i dużym zamrażalnikiem', 1899.99, 'images/samsung_rt38k.jpg'),
(2, 1, 'Lodówka Bosch KGN36', 'Lodówka Bosch o pojemności 320 litrów, klasa energetyczna A++', 1599.99, 'images/bosch_kgn36.jpg'),
(3, 2, 'Pralka LG F4WV5', 'Pralka z funkcją AI, pojemność 9kg, klasa A+++', 2399.99, 'images/lg_f4wv5.jpg'),
(4, 2, 'Pralka Samsung WW80T', 'Pralka o pojemności 8kg, funkcja EcoBubble, klasa energetyczna A+++', 1899.99, 'images/samsung_ww80t.jpg'),
(5, 3, 'Zmywarka Bosch SMS46', 'Zmywarka z 6 programami zmywania, klasa A++', 1599.99, 'images/bosch_sms46.jpg'),
(6, 3, 'Zmywarka Whirlpool WFO3O32', 'Zmywarka o szerokości 60 cm, cicha praca, klasa energetyczna A++', 1399.99, 'images/whirlpool_wfo3o32.jpg'),
(7, 4, 'Odkurzacz Dyson V11', 'Bezprzewodowy odkurzacz z dużą mocą ssania, idealny do wszystkich powierzchni', 2499.99, 'images/dyson_v11.jpg'),
(8, 4, 'Odkurzacz Philips PowerPro', 'Odkurzacz bezworkowy z technologią PowerCyclone 7, mocny i efektywny', 799.99, 'images/philips_powerpro.jpg'),
(9, 1, 'Lodówka Post1', 'Lodówka  Post1', 1899.99, 'images/samsung_rt38k.jpg');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
